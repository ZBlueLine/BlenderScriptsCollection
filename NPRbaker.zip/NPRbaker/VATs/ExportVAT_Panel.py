﻿#修改: Seantong 
## 移除了uv写入的方式 修改为顶点色写入index 还有很多很多处理
import bpy
import bmesh
import numpy as np
from mathutils import Vector;
import math;
import os;

class VATSettingsProperties(bpy.types.PropertyGroup):
    maxValue: bpy.props.FloatProperty(name="Max Value",default = 5 );
    step : bpy.props.IntProperty(name="帧步距",default = 1);
    minValue: bpy.props.FloatProperty(name="Min Value",default =-5);
    exportNormal : bpy.props.BoolProperty(name="Export Normal",default=True);
    exportVertex : bpy.props.BoolProperty(name="Export Vertex",default=True);
    outputPath : bpy.props.StringProperty(name="Output Path",default = "D:\\Output\\",subtype='DIR_PATH');
    framePerLine : bpy.props.IntProperty(name="行/帧",default = 2);
    items = [
            ('0', 'UV0', ""),
            ('1', 'UV1', ""),
            ('2', 'UV2', ""),
            ('3', 'UV3', ""),
            ('4', 'UV4', ""),
            ('5', 'UV5', ""),
            ('6', 'UV6', ""),
            ('7', 'UV7', ""),
        ]
    formatItem = [
            #('PNG', 'PNG', ""),
            #('jpg', 'JPEG', ""),
            #('TARGA', 'TARGA', ""),
            #('HDR', 'HDR', ""),
            ('OPEN_EXR', 'OPEN_EXR', "")
        ]
    colorSpaceItem = [
            ('Gamma', 'Gamma', ""),
            ('Linear', 'Linear', "")
        ]
    writeModeItem = [
            #('SingleRaw', 'SingleRaw', ""),
            ('MultipleRaw', 'MultipleRaw', "")
        ]
    WriteUvID: bpy.props.EnumProperty(
        items=items,
        name="UV ",
        description="写入UV",
        default=None,
        options={'ANIMATABLE'},
        update=None,
        get=None,
        set=None)
    fileFormat: bpy.props.EnumProperty(
        items=formatItem,
        name="文件格式  ",
        description="选择文件格式",
        default=None,
        options={'ANIMATABLE'},
        update=None,
        get=None,
        set=None)
    colorSpace: bpy.props.EnumProperty(
        items=colorSpaceItem,
        name="色彩空间  ",
        description="色彩空间",
        default=None,
        options={'ANIMATABLE'},
        update=None,
        get=None,
        set=None)
    writeMode: bpy.props.EnumProperty(
        items=writeModeItem,
        name="写入方式  ",
        description="写入方式",
        default=None,
        options={'ANIMATABLE'},
        update=None,
        get=None,
        set=None)
    
class VATPanel(bpy.types.Panel):
    """VAT Panel"""
    bl_label = "Vertex Animation Texture"
    bl_idname = "OBJECT_PT_hello"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        layout = self.layout

        obj = context.object
        scene = context.scene
        settings =  scene.VAT_Settings
        
        row = layout.row()
        row.prop(scene, "frame_start")
        row.prop(settings,"step");
        row.prop(scene, "frame_end")
                
        row = layout.row()
        row.prop(settings,"minValue");
        row.prop(settings,"maxValue");
        
        row = layout.row()
        row.prop(settings,"exportVertex");
        row.prop(settings,"exportNormal");
                
        #row = layout.row()
        #row.prop(settings,"WriteUvID");
        
        row = layout.row()
        row.prop(settings,"fileFormat");
        
        row = layout.row()
        row.prop(settings,"colorSpace");
        
        row = layout.row()
        row.prop(settings,"writeMode");
        
        if(settings.writeMode=='MultipleRaw'):
            row = layout.row()
            row.prop(settings,"framePerLine");
                        
        row = layout.row()
        row.prop(settings,"outputPath");
                    
        row = layout.row()
        row.operator("object.generate_vat")

class GenerateVATOperator(bpy.types.Operator):
    
    bl_idname = "object.generate_vat"
    bl_label = "生成VAT"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def execute(self, context):
        scene = context.scene
        settings =  scene.VAT_Settings
        frameStep=settings.step;
        maxValue = settings.maxValue;
        minValue = settings.minValue;
        frameNumber = (scene.frame_end-abs(scene.frame_start))+1;
        frameStart = scene.frame_start;
        
        powValue = 1;
        
        if(settings.colorSpace=='Gamma'):
            powValue = 2.2;
        elif(settings.colorSpace=='Linear'):
            powValue =1;
        print(settings.colorSpace);    
        ExportNormal = settings.exportNormal;
        ExportVertex = settings.exportVertex;

        rangeValue = maxValue-minValue;
        formatDic = {'PNG':'png',
                     #'TARGA':'tga',
                     'HDR':'hdr',
                     'OPEN_EXR':'exr'
                     }
        print("frameNumber"+str(frameNumber));
        
        
        #create folder
        if(not os.path.exists(settings.outputPath)):
            os.makedirs(settings.outputPath);
        #add '\\'    
        if(settings.outputPath[len(settings.outputPath)-1] !='/' and settings.outputPath[len(settings.outputPath)-1] !='\\'):
            settings.outputPath +='\\';
            
        
        def to01(v):
            if(v>maxValue):
                return 1;
            if(v<minValue):
                return 0;
            return (v-minValue)/rangeValue;


        def createImage(name,w,h,alpha):
            img = bpy.data.images.get(name);
            if(img!=None):
                bpy.data.images.remove(img);
                img = None;
            img = bpy.data.images.new(name, width=w, height=h, alpha=alpha, float_buffer=True);
            #img.colorspace_settings.name='Linear'
            img.colorspace_settings.name = 'Raw'
            return img;
    
        # Get the active mesh
        me = context.object.data;
        object = context.object;
        dg = context.evaluated_depsgraph_get();

        if(dg==None):
            print("dg is none!!");
        
        #print( ExportVATSettings.frameNumber);
        bpy.context.scene.frame_set(frameStart);
        bm = bmesh.new();
        #bm.from_object(object,dg);
        bm.from_mesh(me);
        #bmesh.ops.triangulate(bm, faces=bm.faces);


        vertNum =len(bm.verts)

        unitOffset = 1.0 /vertNum;
        half_offset = unitOffset*(0.5);
                        
        #set color 将index 写入顶点色
        id = 0;
        colNum=len(bm.loops.layers.color.values());
        if(colNum==0):
            bm.loops.layers.color.new("color0");
        uv_color=bm.loops.layers.color.values()[0];
        for face in bm.faces:
            for loop in face.loops:
                loop[uv_color].x=(float)(loop.vert.index&0x000000ff)/0x000000ff;
                loop[uv_color].y=(float)(loop.vert.index&0x0000ff00)/0x0000ff00;
                loop[uv_color].z=(float)(loop.vert.index&0x00ff0000)/0x00ff0000;
                loop[uv_color].w=(float)(loop.vert.index&0xff000000)/0xff000000;
        bm.to_mesh(me);
        #bpy.ops.mesh.uv_texture_add();
#        uv_layer = bm.loops.layers.uv.active;
#        uvNumber = len(bm.loops.layers.uv.values());
#        uvIndex = (int(settings.WriteUvID))+1;
#        if(uvNumber<uvIndex):
#            for i in range(uvNumber,uvIndex):
#                bm.loops.layers.uv.new();
        
#        uvIndex = 0;
        #for uv in bm.loops.layers.uv.values():
        #    if(str(uvIndex) == (settings.WriteUvID)):
        #        uv_layer = uv;
        #        break;
        #   uvIndex =uvIndex+1;
#        uv_layer = bm.loops.layers.uv.values()[uvIndex-1];
        resolution=(int)(vertNum/settings.framePerLine)+1;
        #if(vertNum<settings.resolution):resolution=vertNum;
        #单行写入
#        if(settings.writeMode=='SingleRaw'):
#            for f in bm.faces:
#                for loop_data in f.loops:
#                    loop_data[uv_layer].uv.x = id*unitOffset+half_offset;
#                    loop_data[uv_layer].uv.y = 0.0;
#                    id = id +1;
#        #多行写入
#        elif(settings.writeMode=='MultipleRaw'):
#            yunitoffset = 1.0/( math.ceil(vertNum*1.0/resolution)*frameNumber)
#            xunitoffset = 1.0/( resolution)
#            yhalf_offset=0.5*yunitoffset;
#            xhalf_offset=0.5*xunitoffset;
#            
#            for f in bm.faces:
#                for loop_data in f.loops:
#                    loop_data[uv_layer].uv.x = (id%resolution)*xunitoffset + xhalf_offset;
#                    loop_data[uv_layer].uv.y = (int)(id/resolution)*yunitoffset + yhalf_offset;
#                    id = id +1;
#        
#        bm.to_mesh(me);
        space = 0;
        #计算像素数量
        if(settings.writeMode=='SingleRaw'):
            width = vertNum;
            height = (int)(frameNumber/frameStep);
            space = 0;
        elif(settings.writeMode=='MultipleRaw'):
            width = resolution;
            height = math.ceil(vertNum*1.0/resolution)* (int)(frameNumber/frameStep);
            space =  math.ceil(vertNum*1.0/resolution)*resolution-vertNum;
            space = space*4;
            
        print("space= %s" % space);
        print("Verts Number = %s" % vertNum);
        print("width = %s" % width);
        print("height = %s" % height);
             
        if(ExportVertex):
            vertex_data = np.zeros(width*height*4);
            vimg = createImage("Vertex_Texture",width,height,False);
        if(ExportNormal):
            normal_data = np.zeros(width*height*4);
            nimg = createImage("Normal_Texture",width,height,False);

        index = 0;
        # 单行/多行像素写入方式
        for frame in range(frameNumber):
            #抽帧
            if(frame%frameStep==0):
                for v in bm.verts:         
                    #save vertex data
                    if(ExportVertex):
                        wm = object.matrix_world.copy()
                        pos = object.matrix_world@v.co;
                        #vector -> [0,1]
                        x = to01(pos.x);
                        y = to01(pos.y);
                        z = to01(pos.z);
                        vertex_data[index  ] = math.pow(x,powValue);
                        vertex_data[index+1] = math.pow(z,powValue);
                        vertex_data[index+2] = math.pow(y,powValue);
                        vertex_data[index+3] = 1;
                    #save normal data
                    if(ExportNormal):
                        vn = v.normal;
                        normal_data[index  ] = math.pow((vn.x+1)/2.0,powValue);
                        normal_data[index+1] = math.pow((vn.z+1)/2.0,powValue);
                        normal_data[index+2] = math.pow((vn.y+1)/2.0,powValue);
                        normal_data[index+3] = 1;
                    index =index+4;
                #跳过空白部分        
                index = index + space;        
            bm = bmesh.new();
            bm.from_object(object,dg);
            #bmesh.ops.triangulate(bm, faces=bm.faces);
            #Jump Frame
            #这里必须一帧一帧的跳才能 确保物理模拟无误
            bpy.context.scene.frame_set(frameStart +frame);
        #回到第一帧
        bpy.context.scene.frame_set(frameStart);
        #save data    
        if(ExportVertex):
            vimg.pixels[:] = vertex_data;
            vimg.file_format = settings.fileFormat;
            vimg.filepath_raw = settings.outputPath+context.object.name+ "_VAT."+formatDic[settings.fileFormat];
            vimg.save();
        if(ExportNormal):    
            nimg.pixels[:] = normal_data;
            nimg.file_format = settings.fileFormat;
            nimg.filepath_raw = settings.outputPath+context.object.name+"_VAT_N."+formatDic[settings.fileFormat];
            nimg.save();
            
        del bm
        return {'FINISHED'}

#def register():
#    bpy.utils.register_class(GenerateVATOperator);
#    bpy.utils.register_class(VATPanel);
#    bpy.utils.register_class(VATSettingsProperties);
#    bpy.types.Scene.VAT_Settings = bpy.props.PointerProperty(type = VATSettingsProperties)
#
#def unregister():
#    bpy.utils.unregister_class(GenerateVATOperator);
#    bpy.utils.unregister_class(VATPanel);
#    bpy.utils.unregister_class(VATSettingsProperties);
#    del bpy.types.Scene.VAT_Settings
#
#
#if __name__ == "__main__":
#    register()