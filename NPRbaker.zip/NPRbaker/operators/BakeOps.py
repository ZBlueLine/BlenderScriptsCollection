﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
import bmesh
from mathutils import *
from math import *
import numpy as np
import bpy

#*********Bake WrapNormal**********
#*****
def new_GeometryNodes_group():
    ''' Create a new empty node group that can be used in a GeometryNodes modifier.
    '''
    node_group = bpy.data.node_groups.new('GeometryNodes_VMV', 'GeometryNodeTree')
    inNode = node_group.nodes.new('NodeGroupInput')
    #Create Key Mesh Inputs and outputs
    node_group.inputs.new('NodeSocketGeometry', 'Mesh')
    
    #Extrude Mesh
    ExtrNode = node_group.nodes.new('GeometryNodeExtrudeMesh')
    ExtrNode.name = "VMV_ExtrudeNode"
    ExtrNode.inputs['Offset Scale'].default_value = 0.5
    ExtrNode.inputs['Individual'].default_value = False
    node_group.links.new(inNode.outputs['Mesh'], ExtrNode.inputs['Mesh'])
    
    M2Vnode = node_group.nodes.new('GeometryNodeMeshToVolume')
    M2Vnode.inputs['Voxel Amount'].default_value = 64 #Voxel Amount
    M2Vnode.inputs[4].default_value=0.00001 #Exterior Band width
    M2Vnode.inputs[5].default_value=0.00001 #Interior Band width
    node_group.links.new(ExtrNode.outputs["Mesh"], M2Vnode.inputs['Mesh'])
    
    V2Mnode = node_group.nodes.new('GeometryNodeVolumeToMesh')
    node_group.links.new(M2Vnode.outputs['Volume'], V2Mnode.inputs['Volume'])
    
    outNode = node_group.nodes.new('NodeGroupOutput')
    node_group.outputs.new('NodeSocketGeometry', 'Mesh')
    node_group.links.new(V2Mnode.outputs['Mesh'], outNode.inputs['Mesh'])
    
    #inNode.location = Vector((0, 0))
    #outNode.location = Vector((3*outNode.width, 0))
    return node_group

def GetVMVGeoNodeGroup():
    VMVnodegroup = bpy.data.node_groups.get('GeometryNodes_VMV')
    if VMVnodegroup:
        return VMVnodegroup
    else:
        return new_GeometryNodes_group()

def DeleteAttributeByName(Attribs, Name):
    AttIndex = Attribs.find(Name)
    if(AttIndex != -1):
        Attribs.remove(Attribs[AttIndex])

def WrapSelectedObjectTranferNormal():

    #global obj_original, obj_mod
    obj_original = bpy.context.view_layer.objects.active

    if not obj_original:
        print("Nothing Active!!")
        return 

    #Select Target mesh
    obj_original.select_set(True)

    #Apply transforms
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    #Duplicate & selected mesh
    WrapMeshName = obj_original.name+"_WrapMesh"

    for obj in bpy.data.objects:
        if(obj.name == WrapMeshName):
            bpy.data.objects.remove(obj, do_unlink=True)

    bpy.ops.object.duplicate(linked=False)
    obj_mod = bpy.context.active_object
    obj_mod.select_set(True)
    obj_mod.name = obj_original.name+"_WrapMesh"
    """
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.extrude_faces_move(TRANSFORM_OT_shrink_fatten={"value":0.5})
    bpy.ops.object.editmode_toggle()"""#Extrude operation move to GeoNode

    #Add Solidify in case of open face(foliage open face most of the time)
    bpy.ops.object.modifier_add(type='SOLIDIFY')
    mod_solidify = obj_mod.modifiers[-1]
    mod_solidify.name = 'VMVPre_Solidify'

    #Add Geometry node modifier
    bpy.ops.object.modifier_add(type='NODES') 
    #Define node group internals

    # In 3.2 Adding the modifier no longer automatically creates a node group.
    # This test could be done with versioning, but this approach is more general
    # in case a later version of Blender goes back to including a node group.
    if obj_mod.modifiers[-1].node_group:
        node_group = obj_mod.modifiers[-1].node_group    
    else:
        node_group = GetVMVGeoNodeGroup()
        obj_mod.modifiers[-1].node_group = node_group
        obj_mod.modifiers[-1].name = "VMV_GeoNode"

    #Apply MVM geometry node
    mod_MVM = obj_mod.modifiers[-1]
    bpy.ops.object.modifier_apply(modifier=mod_MVM.name)

    #Add Smooth modifier & apply
    bpy.ops.object.modifier_add(type='SMOOTH')
    mod_smooth = obj_mod.modifiers[-1]
    mod_smooth.name = 'VMVPost_Smooth'
    mod_smooth.iterations = 25
    bpy.ops.object.modifier_apply(modifier=mod_smooth.name)

    #Deselected ALL
    bpy.ops.object.select_all(action='DESELECT')

    #Select Original mesh
    bpy.context.view_layer.objects.active = obj_original
    obj_original.select_set(True)

    #Add Data transfer modifier & apply
    obj_original.data.use_auto_smooth = True
    bpy.ops.object.modifier_add(type='DATA_TRANSFER')
    mod_datatrans = obj_original.modifiers[-1]
    mod_datatrans.name = 'Post_datatrans'
    mod_datatrans.use_loop_data = True
    mod_datatrans.data_types_loops = {'CUSTOM_NORMAL'}
    mod_datatrans.loop_mapping = 'POLYINTERP_NEAREST'
    mod_datatrans.object = obj_mod
    bpy.ops.object.modifier_apply(modifier=mod_datatrans.name)


    #Hide modified mesh
    obj_mod.hide_viewport = True

    #me = mesh.data
    #bm = bmesh.from_edit_mesh(me)

#First half of the wrapnormal baking this makes adjusting wrapmesh possible~
def GenerateWrapMesh():
    
    #global obj_original, obj_mod
    obj_original = bpy.context.view_layer.objects.active

    if not obj_original:
        print("Nothing Active!!")
        return

    #Select Target mesh
    obj_original.select_set(True)

    #Apply transforms
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    #Duplicate & selected mesh
    WrapMeshName = obj_original.name+"_WrapMesh"

    for obj in bpy.data.objects:
        if(obj.name == WrapMeshName):
            bpy.data.objects.remove(obj, do_unlink=True)

    bpy.ops.object.duplicate(linked=False)
    obj_mod = bpy.context.active_object
    obj_mod.select_set(True)
    obj_mod.name = WrapMeshName

    #Add Solidify in case of open face(foliage open face most of the time)
    bpy.ops.object.modifier_add(type='SOLIDIFY')
    mod_solidify = obj_mod.modifiers[-1]
    mod_solidify.name = 'VMVPre_Solidify'

    #Add Geometry node modifier
    bpy.ops.object.modifier_add(type='NODES') 
    mod_geoNode = obj_mod.modifiers[-1]
    mod_geoNode.name = 'VMV_GeoNode'
    #Define node group internals

    # In 3.2 Adding the modifier no longer automatically creates a node group.
    # This test could be done with versioning, but this approach is more general
    # in case a later version of Blender goes back to including a node group.
    if obj_mod.modifiers[-1].node_group:
        node_group = obj_mod.modifiers[-1].node_group    
    else:
        node_group = GetVMVGeoNodeGroup()
        obj_mod.modifiers[-1].node_group = node_group

    bpy.ops.object.modifier_add(type='SMOOTH')
    mod_smooth = obj_mod.modifiers[-1]
    mod_smooth.name = 'VMVPost_Smooth'
    mod_smooth.iterations = 25

    #Deselected ALL
    bpy.ops.object.select_all(action='DESELECT')

    #Select Original mesh
    bpy.context.view_layer.objects.active = obj_original
    obj_original.select_set(True)

    return obj_mod, node_group.nodes["VMV_ExtrudeNode"]

def TransferWrapNormal():
    obj_original = bpy.context.view_layer.objects.active

    WrapMeshName = obj_original.name+"_WrapMesh"
    try:
        obj_warpmesh = bpy.data.objects[WrapMeshName]
    except:
        raise TypeError("Active does not have a wrapmesh!!")

    #Select wrap mesh
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj_warpmesh
    obj_warpmesh.select_set(True)

    bpy.ops.object.modifier_apply(modifier="VMVPre_Solidify")
    bpy.ops.object.modifier_apply(modifier="VMV_GeoNode")
    bpy.ops.object.modifier_apply(modifier="VMVPost_Smooth")

    #Select Original mesh
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj_original
    obj_original.select_set(True)

    #Add Data transfer modifier & apply
    obj_original.data.use_auto_smooth = True
    bpy.ops.object.modifier_add(type='DATA_TRANSFER')
    mod_datatrans = obj_original.modifiers[-1]
    mod_datatrans.name = 'Post_datatrans'
    mod_datatrans.use_loop_data = True
    mod_datatrans.data_types_loops = {'CUSTOM_NORMAL'}
    mod_datatrans.loop_mapping = 'POLYINTERP_NEAREST'
    mod_datatrans.object = obj_warpmesh
    #bpy.ops.object.modifier_apply(modifier=mod_datatrans.name)
    
    obj_warpmesh.hide_viewport = True
def checkVertexColorAttribute(mesh):
    if(mesh==None):
        print("mesh is none");
        return;
    colCount=len(mesh.color_attributes);
    if(colCount==0):
        vc=mesh.color_attributes.new(
            name='Color0',
            type='BYTE_COLOR',
            domain='CORNER',
        )
    return mesh.color_attributes[0];

def checkVertexUVMapAttribute(mesh):
    if(mesh==None):
        print("mesh is none");
        return;
    uvMapCount=len(mesh.uv_layers);
    if(uvMapCount!=0):
        mesh.calc_tangents(uvmap = mesh.uv_layers[0].name)
    else:
        print("mesh does not have UVMap");

def vec2str(vec):
    return "x=" + str(vec.x) + ",y=" + str(vec.y) + ",z=" + str(vec.z)

def cross_product(v1, v2):
    return Vector((v1.y*v2.z-v1.z*v2.y, v1.z*v2.x-v1.x*v2.z, v1.x*v2.y-v1.y*v2.x))

def vector_length(v):
    return sqrt(v.x*v.x + v.y*v.y + v.z*v.z)

def normalize(v):
    return v/vector_length(v)

def dot_product(v1, v2):
    return v1.x*v2.x+v1.y*v2.y+v1.z*v2.z

def included_angle(v1, v2):
    return np.arccos(dot_product(v1,v2)/(vector_length(v1)*vector_length(v2)))

#*********Bake WrapAO**********
#*****
def getRayCastDirections():
    #Using an IsoSphere vertex to get the raycast directions for each point
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=1, enter_editmode=False, location=(0, 0, 0))
    Sphere = bpy.context.object
    Sphere.name = "RaycastSphere"
    
    raycastDirs = [vert.co for vert in Sphere.data.vertices]
    #Vector.normalize()
    #we are going to use the verts.co as raycast direction for 360 coverage
    bpy.data.objects.remove(Sphere, do_unlink=True)
    return raycastDirs
    #RCDirs = getRayCastDirections()
    
def raycastAllDirection(obj, vetPos, rcDirs, rcLength):
    # Cast  rays
    ray_origin = vetPos
    valueSignDist = 99999999
    for dir in rcDirs:
        success, location, normal, poly_index = obj.ray_cast(ray_origin, dir, distance = rcLength)
        if(success):
            value = (location-vetPos).length
            value = math.copysign(value,-Vector.dot(dir, normal))
            if(abs(value)<abs(valueSignDist)):
                valueSignDist = value
    return valueSignDist
def saveSDasVertexColor(obj, signDists, wm):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    mesh = obj.data
    if (3, 6, 0) > bpy.app.version:#3.6版本之前，使用原有VertexColor赋予
        bpy.ops.object.mode_set(mode = 'VERTEX_PAINT')
        for vertindex in range(len(signDists)):
            for polygon in mesh.polygons:
                for i, index in enumerate(polygon.vertices):
                    if vertindex == index:
                        loop_index = polygon.loop_indices[i]
                        r = signDists[vertindex]
                        ao=math.pow(r,bpy.context.scene.VERTTOOLS_Settings.AOPower)
                        mesh.vertex_colors.active.data[loop_index].color = [ao,ao,ao,1.0]
            wm.progress_update(int((vertindex/len(signDists)) * 45) + 55)
    else:#3.6版本之之后，使用Attribute赋予
        checkVertexColorAttribute(mesh);
        att_color=mesh.color_attributes[0];
        for vertindex in range(len(signDists)):
            for i,index in enumerate(mesh.vertices):
                if vertindex == i:
                    r = signDists[vertindex]
                    try:
                        ao=math.pow(r,bpy.context.scene.VERTTOOLS_Settings.AOPower)
                        att_color.data[i].color[3]=ao
                        #print('Suc')
                    except Exception as err:
                        print('fail',err)
            wm.progress_update(int((vertindex/len(signDists)) * 45) + 55)

    bpy.ops.object.mode_set(mode = 'OBJECT')


def BakeAOUsingWrapMesh():
    context = bpy.context
    wm = bpy.context.window_manager
    wm.progress_begin(0, 100)

    obj_original = bpy.context.view_layer.objects.active
    # make sure in object mode
    bpy.ops.object.mode_set(mode = 'OBJECT')

    if not obj_original:
        print("Nothing Active!!")

    #Select Target mesh
    obj_original.select_set(True)

    WrapMeshName = obj_original.name+"_WrapMesh"
    try:
        obj_warpmesh = bpy.data.objects[WrapMeshName]
    except:
        obj_warpmesh, node = GenerateWrapMesh()

    #get all vertex position
    vetPoss = [vert.co for vert in obj_original.data.vertices]

    #get raycast directions for each vert
    rcDirs = getRayCastDirections()

    #raycastlength
    rcLength = max(max(obj_warpmesh.dimensions.x, obj_warpmesh.dimensions.y),obj_warpmesh.dimensions.z)
    
    #depsgraph = context.evaluated_depsgraph_get()
    #depsgraph.update()  # just in case
    #obj = obj_warpmesh.evaluated_get(depsgraph)
    obj_warpmesh.hide_viewport = False

    #get Sign distance for All vert using raycast(percent 0%~45%)
    signDist = []
    for i in range(len(vetPoss)):
        signDist.append(raycastAllDirection(obj_warpmesh, vetPoss[i], rcDirs, rcLength))
        wm.progress_update(int(i/len(vetPoss) * 45))

    #normalize SDF value to 0~1 (percent 45%~55%)
    obj_warpmesh.hide_viewport = True
    maxDist = max(signDist)
    minDist = min(signDist)
    for i in range(len(vetPoss)):
        signDist[i] = (signDist[i]-minDist)/(maxDist-minDist)
        signDist[i] = signDist[i]*signDist[i]
    wm.progress_update(55)
    
    #Save SDF AO to Vertex Color(percent 55%~100%)
    saveSDasVertexColor(obj_original, signDist, wm)

#**********Operators************
#**
class BakeWarpNomral(bpy.types.Operator):
    """Generate Wrap mesh for selected mesh and transfer normal to mesh"""      # Use this as a tooltip for menu items and buttons.
    bl_idname = "object.bake_wrap_normal"        # Unique identifier for buttons and menu items to reference.
    bl_label = "Wrap Mesh->Normal"         # Display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # Enable undo for the operator.
    
    @classmethod
    def poll(cls, context):
        return bpy.context.view_layer.objects.active is not None

    def execute(self, context):        # execute() is called when running the operator.
        # The original script
        WrapSelectedObjectTranferNormal()
        return {'FINISHED'}            # Lets Blender know the operator finished successfully.

class BakeWarpAO(bpy.types.Operator):
    """Bake Wrap AO to selected mesh using wrap mesh"""      # Use this as a tooltip for menu items and buttons.
    bl_idname = "object.bake_wrap_ao"        # Unique identifier for buttons and menu items to reference.
    bl_label = "Bake Wrap AO->Alpha"         # Display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # Enable undo for the operator.

    @classmethod
    def poll(cls, context):
        return bpy.context.view_layer.objects.active is not None

    def execute(self, context):        # execute() is called when running the operator.
        # The original script)
        BakeAOUsingWrapMesh()
        return {'FINISHED'}            # Lets Blender know the operator finished successfully.

class BakeWarpNomralModal(bpy.types.Operator):
    bl_idname = "object.bake_wrap_normal_modal"
    bl_label = "Wrap Mesh->Normal"
    bl_options = {'REGISTER', 'UNDO'} 

    @classmethod
    def poll(cls, context):
        return bpy.context.view_layer.objects.active is not None

    def __init__(self):
        print("Start Test modal")

    def __del__(self):
        print("End Test modal")

    def execute(self, context):
        self.extrudeNode.inputs['Offset Scale'].default_value = self.value 
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        settings=context.scene.VERTTOOLS_Settings
        if event.type == 'MOUSEMOVE':  # Apply
            self.value = (event.mouse_x-self.init_mouse_pos_x)/settings.warpScale*self.init_value
            self.execute(context)
        elif event.type == 'LEFTMOUSE':  # Confirm
            TransferWrapNormal()
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            self.value = self.init_value
            bpy.ops.ed.undo()#revert all stuff
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        #move mouse to center for better move
        region = context.region
        cx = region.width // 2
        cy = region.height // 2
        context.window.cursor_warp(cx, cy)

        self.init_value = 0.5
        self.init_mouse_pos_x = cx
        self.value = 0.5

        self.wrapMesh, self.extrudeNode = GenerateWrapMesh()
        self.extrudeNode.inputs['Offset Scale'].default_value = self.value
        

        self.execute(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class BakeSmoothNormal2Color(bpy.types.Operator):
    bl_idname = "object.bake_smooth_normal_2_color"
    bl_label = "Bake Normal->RGB"
    bl_options = {'REGISTER', 'UNDO'} 
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects)!=0;

    def execute(self, context):
        scene = context.scene
        #settings =  scene.NPR_Settings

        # Get the active mesh
        for obj in context.selected_objects:
            mesh = obj.data;
            object = context.object;
            dg = context.evaluated_depsgraph_get();
            if(dg==None):
                print("dg is none!!");
            checkVertexColorAttribute(mesh);
            checkVertexUVMapAttribute(mesh)

            dict = {}
            def need_outline(vertex):
                need = True
                return need

            for v in mesh.vertices:
                co = v.co
                co_str = vec2str(co)
                dict[co_str] = []

            for poly in mesh.polygons:
                l0 = mesh.loops[poly.loop_start]
                l1 = mesh.loops[poly.loop_start + 1]
                l2 = mesh.loops[poly.loop_start + 2]
                
                v0 = mesh.vertices[l0.vertex_index]
                v1 = mesh.vertices[l1.vertex_index]
                v2 = mesh.vertices[l2.vertex_index]
                
                n = cross_product(v1.co - v0.co, v2.co - v0.co)
                if vector_length(n) == 0:
                    continue
                n = normalize(n)
                
                co0_str = vec2str(v0.co)
                co1_str = vec2str(v1.co)
                co2_str = vec2str(v2.co)
                
                if co0_str in dict:
                    w = included_angle(v2.co - v0.co, v1.co - v0.co)
                    dict[co0_str].append({"n":n, "w":w, "l":l0})
                if co1_str in dict:
                    w = included_angle(v0.co - v1.co, v2.co - v1.co)
                    dict[co1_str].append({"n":n, "w":w, "l":l1})
                if co2_str in dict:
                    w = included_angle(v1.co - v2.co, v0.co - v2.co)
                    dict[co2_str].append({"n":n, "w":w, "l":l2})
                    
                    
            for poly in mesh.polygons:
                for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
                    vertex_index = mesh.loops[loop_index].vertex_index
                    v = mesh.vertices[vertex_index]
                    smoothnormal = Vector((0, 0, 0))
                    weightsum = 0
                    alpha = 1
                    if need_outline(v):
                        costr = vec2str(v.co)
                        if costr in dict:
                            a = dict[costr]
                            for d in a:
                                n = d['n']
                                w = d['w']
                                smoothnormal += n * w
                                weightsum += w;
                                print(costr + " : "+ str(w))
                    if smoothnormal != Vector((0, 0, 0)):
                        smoothnormal /= weightsum
                        smoothnormal = normalize(smoothnormal)
                    
                    normal = mesh.loops[loop_index].normal    
                    tangent = mesh.loops[loop_index].tangent    
                    bitangent = mesh.loops[loop_index].bitangent    
                    
                    normalTSX = dot_product(tangent, smoothnormal);
                    normalTSY = dot_product(bitangent, smoothnormal);
                    normalTSZ = dot_product(normal, smoothnormal);
                    
                    normalTS = Vector((normalTSX, normalTSY, normalTSZ))
                    color = [normalTS.x * 0.5 + 0.5, normalTS.y * 0.5 + 0.5 , normalTS.z * 0.5 + 0.5, alpha]
                    mesh.color_attributes[0].data[loop_index].color = color
        return {'FINISHED'}

# class BakeSmoothNormal2Color(bpy.types.Operator):
#     bl_idname = "object.bake_smooth_normal_2_color"
#     bl_label = "Bake Normal->RGB"
#     bl_options = {'REGISTER', 'UNDO'} 
#     @classmethod
#     def poll(cls, context):
#         return len(context.selected_objects)!=0;

#     def execute(self, context):
#         scene = context.scene
#         #settings =  scene.NPR_Settings

#         # Get the active mesh
#         for obj in context.selected_objects:
#             mesh = obj.data;
#             object = context.object;
#             dg = context.evaluated_depsgraph_get();
#             if(dg==None):
#                 print("dg is none!!");
#             checkVertexColorAttribute(mesh);

#             bm = bmesh.new();
#             bm.from_mesh(mesh);
        
#             print(len(mesh.color_attributes));
#             print(len(bm.loops.layers.color));
#             #normal 写入顶点色
#             #colNum=len(bm.loops.layers.color.values());
#             #if(colNum==0):
#             #bm.loops.layers.color.new("color0");

#             uv_color=bm.loops.layers.color.values()[0];
#             #对应unity 中 我们需要转轴
#             for face in bm.faces:
#                 for loop in face.loops:
#                     vn=loop.vert.normal;
#                     loop[uv_color].x=(vn.x+1)/2.0;
#                     loop[uv_color].y=(vn.y+1)/2.0;
#                     loop[uv_color].z=(vn.z+1)/2.0;
#             bm.to_mesh(mesh);
#             del bm
#         return {'FINISHED'}
    