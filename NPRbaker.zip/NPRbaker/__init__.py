﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "NPR RenderingData Baker",
    "description": "Bake VertexData for stylized Art",
    "author": "Sean Tong",
    "version": (0, 2),
    "blender": (3, 6, 0),
    "category": "Object",
}


if "bpy" in locals():
    import importlib
    importlib.reload(operators.BakeOps)
    importlib.reload(operators.ViewOps)
    importlib.reload(VATs.ExportVAT_Panel)

else:
    import bpy
    from .operators import BakeOps 
    from .operators import ViewOps 
    from .VATs import ExportVAT_Panel


#Object 面板
class NPRBaker_Pannel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "NPR Baker"
    bl_idname = "object.wrap_baker"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        layout = self.layout

        obj = context.object
        scene = context.scene
        settings =  scene.VAT_Settings
        
        row = layout.row()
        row.prop(scene, "frame_start")
        row.prop(settings,"step");
        row.prop(scene, "frame_end")
                
        row = layout.row()
        row.prop(settings,"minValue");
        row.prop(settings,"maxValue");
        
        row = layout.row()
        row.prop(settings,"exportVertex");
        row.prop(settings,"exportNormal");
                
        #row = layout.row()
        #row.prop(settings,"WriteUvID");
        
        row = layout.row()
        row.prop(settings,"fileFormat");
        
        row = layout.row()
        row.prop(settings,"colorSpace");
        
        row = layout.row()
        row.prop(settings,"writeMode");
        
        if(settings.writeMode=='MultipleRaw'):
            row = layout.row()
            row.prop(settings,"framePerLine");
                        
        row = layout.row()
        row.prop(settings,"outputPath");
                    
        row = layout.row()
        row.operator("object.generate_vat")


class VERTTOOLS_Properties(bpy.types.PropertyGroup):
    warpScale:bpy.props.FloatProperty(name="Warp Scale",default = 400 );
    AOPower:bpy.props.FloatProperty(name="AO Power",default = 1 );
        
#3D视图右侧工具面板
class WRAPBAKER_PT_Panel(bpy.types.Panel):
    bl_idname      = "WRAPBAKER_PT_Panel"
    bl_label       = "NPR Baker"
    bl_category    = "NPR Baker"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_context     = "objectmode"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        wm = context.window_manager
        scene = context.scene

        view_option_column = layout.row()
        label = "VertNormalView ON" if scene.vert_normal_view else "VertNormalView OFF"
        view_option_column.prop(scene, 'vert_normal_view', text=label, toggle=True)
        label = "VertColorView ON" if scene.vert_color_view else "VertColorView OFF"
        view_option_column.prop(scene, 'vert_color_view', text=label, toggle=True)

        #settings
        settings =  scene.VERTTOOLS_Settings
        row = layout.row()
        row.prop(settings,"warpScale");
        row.prop(settings,"AOPower");

        normal_bake_row= layout.row()
        normal_bake_row.operator("object.bake_wrap_normal_modal",text="Create Wrap Mesh->Normal")
        AO_bake_row= layout.row()
        AO_bake_row.operator("object.bake_wrap_ao",text="Bake Wrap AO->Alpha")
        Smooth_bake_row= layout.row()
        Smooth_bake_row.operator(BakeOps.BakeSmoothNormal2Color.bl_idname)

        #Testmodel= layout.row()
        #Testmodel.operator("object.test_modal_op",text="Test simple modal")

class WRAPBAKER_PT_VertPaintPanel(bpy.types.Panel):
    bl_idname      = "WRAPBAKER_PT_VertPaintPanel"
    bl_label       = "NPR Baker"
    bl_category    = "NPR Baker"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_context     = "vertexpaint"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        view_option_column = layout.row()
        label = "VertNormalView ON" if scene.vert_normal_view else "VertNormalView OFF"
        view_option_column.prop(scene, 'vert_normal_view', text=label, toggle=True)
        label = "VertColorView ON" if scene.vert_color_view else "VertColorView OFF"
        view_option_column.prop(scene, 'vert_color_view', text=label, toggle=True)


#Object 下拉菜单
def menu_func(self, context):
    self.layout.label(text="Wrap Baker")
    self.layout.operator(BakeOps.BakeWarpNomral.bl_idname)
    self.layout.operator(BakeOps.BakeWarpAO.bl_idname)

def register():
    #Settings
    bpy.utils.register_class(VERTTOOLS_Properties)
    bpy.types.Scene.VERTTOOLS_Settings = bpy.props.PointerProperty(type = VERTTOOLS_Properties)

    bpy.utils.register_class(BakeOps.BakeWarpNomralModal)
    bpy.utils.register_class(BakeOps.BakeWarpAO)
    
    #obj pannel
    bpy.utils.register_class(NPRBaker_Pannel)
    bpy.utils.register_class(BakeOps.BakeSmoothNormal2Color)

    bpy.types.VIEW3D_MT_object.append(menu_func)
    bpy.utils.register_class(WRAPBAKER_PT_Panel)
    bpy.utils.register_class(WRAPBAKER_PT_VertPaintPanel)
    #VATs
    bpy.utils.register_class(ExportVAT_Panel.GenerateVATOperator);
    #bpy.utils.register_class(ExportVAT_Panel.VATPanel);
    bpy.utils.register_class(ExportVAT_Panel.VATSettingsProperties);
    bpy.types.Scene.VAT_Settings = bpy.props.PointerProperty(type = ExportVAT_Panel.VATSettingsProperties)

def unregister():
    bpy.utils.unregister_class(BakeOps.BakeWarpNomralModal)
    bpy.utils.unregister_class(BakeOps.BakeWarpAO)


    bpy.types.VIEW3D_MT_object.remove(menu_func)
    bpy.utils.unregister_class(WRAPBAKER_PT_Panel)
    bpy.utils.unregister_class(WRAPBAKER_PT_VertPaintPanel)
    #obj pannel
    bpy.utils.unregister_class(NPRBaker_Pannel)
    bpy.utils.unregister_class(BakeOps.BakeSmoothNormal2Color)
    #Settings
    bpy.utils.unregister_class(VERTTOOLS_Properties);
    del bpy.types.Scene.VERTTOOLS_Settings
    #VATs
    bpy.utils.unregister_class(ExportVAT_Panel.GenerateVATOperator);
    #bpy.utils.unregister_class(ExportVAT_Panel.VATPanel);
    bpy.utils.unregister_class(ExportVAT_Panel.VATSettingsProperties);
    del bpy.types.Scene.VAT_Settings

# This allows you to run the script directly from Blender's Text editor
# to test the add-on without having to install it.
if __name__ == "__main__":
    register()